<?php
require_once 'security.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title></title>
  <?php require_once 'components/links.php'; ?>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <?php require_once 'components/navbar.php'; ?>
<section id="programming " style="padding-top:100px">
<div class="container-fluid d-flex justify-content-between px-5">
  <p class="programming-heading"><i class="fa fa-file-o" aria-hidden="true"></i> &nbsp;Users</p>
                                   <!-- Button trigger modal -->
    <button type="button" class="btn button-primary" data-toggle="modal" data-target="#uploaduser">
    Add User
    </button>                          
</div>
<br>
<div class="container-fluid d-flex justify-content-between px-5">                        
 <input id="search" type="text"  class="form-control col-md-4" placeholder="Search Programs"> 
</div>
<br>
            <!-- Program Upload  Modal -->
            <div class="modal fade" id="uploaduser" tabindex="-1" role="dialog" aria-labelledby="uploadprogramTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Add User</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                 
          <form action="code.php" method="POST">

          <div class="form-group">
   			<label>User</label>
   			<input type="text" name="user" class="form-control" placeholder="Enter user name" required>
        </div>

        <div class="form-group">
   			<label>Email</label>
   			<input type="email" name="email" class="form-control" placeholder="Email" required>
        </div>
              
          <div class="form-group">
   			<label>Password</label>
   			<input type="text" name="password"  class="form-control" placeholder="Enter Password " required>
          </div>

          </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit"  name="add_user" class="btn btn-primary">Add User</button>
                </div>

                </form>
                </div>
            </div>
            </div>
       
            <!-- Program  Update  Modal -->
            <div class="modal fade" id="update_user" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Update User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
                <div class="modal-body">
                <form action="code.php" method="POST">

       <input  name="update_userid" id="update_userid">

          <div class="form-group">
   			<label>User</label>
   			<input type="text" name="user" id="user" class="form-control" placeholder="Enter Program Url" required>
        </div>
              
        <div class="form-group">
   			<label>Email</label>
   			<input type="email" name="email" id="email" class="form-control" placeholder="Enter Program Title" required>
        </div>

          <div class="form-group">
   			<label>Password</label>
   			<input type="text" name="password" id="password"  class="form-control" placeholder="Enter Program " required>
          </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" name="update_user"  class="btn btn-primary">Update Program</button>
                </div>

                </form>
                </div>
            </div>
            </div>
              


              
            <!-- Program Delete  Modal -->
            <div class="modal fade" id="delete_user" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Delete User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      
<form action="code.php" method="POST">
                        
         <input type="hidden" name="delete_userid" id="delete_userid">     

         <h4>Do You Want to Delete this User ?</h4>     
      
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">NO</button>
        <button type="submit" name="delete_user"  class="btn btn-primary">YES</button>
     </div>

 </form>
    </div>
  </div>
</div>
 </section>

<section id="displaytable" class="mx-5">
        
<?php

if(isset($_SESSION['success']) && $_SESSION['success']!='')
{
    echo'<div class="alert alert-primary text-center font-weight-bold" role="alert">'.$_SESSION['success'].'</div>';
    unset($_SESSION['success']);
}

if(isset($_SESSION['status']) && $_SESSION['status']!='')
{
    echo'<div class="alert alert-danger text-center font-weight-bold" role="alert">'.$_SESSION['status'].'</div>';
    unset($_SESSION['status']);
}

?>

<div class="table-responsive">
<?php
 $query1 = " SELECT * FROM user ";
 $query_run1 = mysqli_query($connection,$query1);
 ?>

<table  class="table table-striped table-hover table-bordered" id="datatable" width="100%" cellspacing="0" >
<thead style="background-color:#618CC2 !important;">
    <tr>
    <th style="display:none;">ID</th>
      <th><span onclick='sortTable("user");'>USER</span></th>
      <th><span onclick='sortTable("email");'>EMAIL</span></th>
      <th><span onclick='sortTable("password");'>PASSWORD</span></th>
      <th>UPDATE</th>
      <th>DELETE</th>
  </tr>
</thead>
<tbody id="searchdata">

   <?php

     if(mysqli_num_rows($query_run1) > 0)
     {
       while($row1 = mysqli_fetch_assoc($query_run1))
       {
       ?>

  <tr>

    <td style="display:none;"><?php echo $row1['id']; ?></td>
    <td><?php echo $row1['user']; ?></td>
    <td><?php echo $row1['email']; ?></td>
    <td><?php echo $row1['password']; ?></td>
    <td class="text-center"><button type="button"  class="btn button-success update_user" data-toggle="modal" data-target="#update_user">
    UPDATE
  </button></td>
    <td class="text-center"><button type="button"  class="btn button-danger delete_user" data-toggle="modal" data-target="#delete_user">
     DELETE
  </button></td>
   </tr>



  <?php
  }
}
else
{
  echo '<div class="alert alert-danger text-center font-weight-bold" role="alert">NO PROGRAMS FOUND IN YOUR LAB</div>';
}

?>
</tbody>
</table>
</div>

</section>




  <?php require_once 'components/footer.php'; ?>


</body>

</html>


