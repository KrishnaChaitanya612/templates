<?php

include_once "database.php";
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title></title>

  
  <link rel="stylesheet" href="style.css">
  <meta charset="UTF-8">
    <meta name="theme-color" content="#F05F40">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://unpkg.com/bootstrap-material-design@4.1.1/dist/css/bootstrap-material-design.min.css" integrity="sha384-wXznGJNEXNG1NFsbm0ugrLFMQPWswR3lds2VeinahP8N0zJw9VWSopbjv2x7WCvX" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://unpkg.com/popper.js@1.12.6/dist/umd/popper.js" integrity="sha384-fA23ZRQ3G/J53mElWqVJEGJzU0sTs+SvzG8fXVWP+kJQ1lwFAOkcUOysnlKJC33U" crossorigin="anonymous"></script>
<script src="https://unpkg.com/bootstrap-material-design@4.1.1/dist/js/bootstrap-material-design.js" integrity="sha384-CauSuKpEqAFajSpkdjv3z9t8E7RlpJ1UP0lKM/+NdtSarroVKu069AlsRPKkFBz9" crossorigin="anonymous"></script>
<script>$(document).ready(function() { $('body').bootstrapMaterialDesign(); });</script>
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Login</title>
    <link rel="shortcut icon" href="assets/img/logo.png" sizes="16x16" />
  
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap');
    body{
        background:#F5F8F8;
        font-family:'Poppins',sans-serif;
    }
    .logo-brand{
        color:#000;
        font-size:35px;
        font-weight:700;
    }
    .logo-brand span{
        color:#6d99d6;
    }
    .heading img{
        padding-bottom:10px;
    }

    .login-btn{
        padding:10px 75px;
        border-radius:25px;
        border:2px solid #6d99d6;
        background:#fff;
        color:#6d99d6;
        font-size:17px;
        font-weight:600;
        cursor:pointer;
    }
    .login-btn:hover{
       outline-color:#fff;
        border:2px solid #fff;
        background:#6d99d6;
        color:#fff;
    }
    .navbar-brand{
	color: #000 !important;
	font-weight: bold !important;
	height: 50px;
	font-size: 25px !important;
}



    @media screen and (max-width:769px) and (min-width: 0px) {
        .login-form{
        padding-top:3px;
    }
    .desktop-only {
    display: none;
 }
 }
 
 
 @media (min-width: 1025px) {
  
    .login-form{
        padding-top:70px;
    }
    .mobile-only {
    display: none;
 }
  
 }
 @media (min-width: 770px) and (max-width: 1024px) {
  
    .login-form{
        padding-top:3px;
    }
    .mobile-only {
    display: none;
 }
 }
    </style>

</head>

<div class="container">

        <div class="heading d-flex justify-content-between pt-4">
            <a class="navbar-brand pt-2 pl-2" href="index.php">Name<span style="color:#6d99d6;">Login</span> </a>
        </div>

        <div class="row text-center">
            <div class="col-md-6">
                <img src="assets/img/intro-image.png" alt="" class="img-fluid">
            </div>
        <div class="col-md-6 text-left login-form">
        
        <form action="code.php" method="POST">
             <p class="logo-brand text-center"><i class="fa fa-sign-in" aria-hidden="true"></i> <span>Log</span>In</p>
             <?php

            if(isset($_SESSION['success']) && $_SESSION['success']!='')
            {
                echo'<div class="alert alert-primary text-center font-weight-bold" role="alert">'.$_SESSION['success'].'</div>';
                unset($_SESSION['success']);
            }

            if(isset($_SESSION['status']) && $_SESSION['status']!='')
            {
                echo'<div class="alert alert-danger text-center font-weight-bold" role="alert">'.$_SESSION['status'].'</div>';
                unset($_SESSION['status']);
            }

         ?>
                 <div class="form-group">
                    <label for="exampleInputEmail1" class="bmd-label-floating">Name :</label>
                    <input type="text" name="user" class="form-control" required>
                    <span class="bmd-help">Please Enter Your Valid Name</span>
                </div>

                <div class="form-group">
                    <label for="exampleInputEmail1" class="bmd-label-floating">Email :</label>
                    <input type="email" name="email" class="form-control" required>
                    <span class="bmd-help">Please Enter Your Valid Email</span>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1" class="bmd-label-floating">Password :</label>
                    <input type="password" name="password" class="form-control" id="myInput" required>
                    <span class="bmd-help">Please Enter Your Password</span>
                </div>
                <br>
                <div class="form-group">
                    <input type="checkbox" onclick="myFunction()">&nbsp;Show Password
                </div>   
                
                <div class="text-center">
                    <button type="submit" name="user_register" class="login-btn">Login</button>
                </div>

        </form>
         <p>Already a user? Login <a href="http://localhost/templates/login.php">Here</a></p>
        </div>
        </div>
    </div>

<hr class="mobile-only">
    <footer>
    <!-- <p class="font-weight-bold text-center">&copy; <?php echo date('Y') ?> SimulEduco. All Rights Reserved | <a href="">Privacy Policy</a></p> -->
    </footer>

<script>

function myFunction() {
  var x = document.getElementById("myInput");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}

</script>


</body>
</html>


