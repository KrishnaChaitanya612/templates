<?php

require_once 'security.php';

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title></title>
<style>
  /* Make the image fully responsive */
  .carousel-inner img {
    width: 100%;
    height: 100%;
  }
  .header-text {
    position: absolute;
    top: 20%;
    left: 1.8%;
    right: auto;
    width: 96.66666666666666%;
    color: #fff;
}
  </style>
  <?php require_once 'components/links.php'; ?>
  <link rel="stylesheet" href="style.css">

</head>

<body>

  <?php require_once 'components/navbar.php'; ?>

    <div id="demo" class="carousel slide" data-ride="carousel">

  <!-- Indicators -->
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  
  <!-- The slideshow -->
  <div class="carousel-inner"style="padding-top:80px;" >
    <div class="carousel-item active">
      <img src="https://cdn.educba.com/academy/wp-content/uploads/2019/09/Image-Link-in-HTML-final-1.png.webp" width="1100" height="500" alt="Los Angeles" >
     <div class="header-text hidden-xs">
                        <div class="col-md-12 text-center">
                            <h2>
                            	<span>Welcome to <strong>LOREM IPSUM</strong></span>
                            </h2>
                            <br>
                            <h3>
                            	<span>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</span>
                            </h3>
                            <br>
                            <div class="">
                                <a class="btn btn-theme btn-sm btn-min-block" href="#">Login</a><a class="btn btn-theme btn-sm btn-min-block" href="#">Register</a></div>
                        </div>
                    </div>
    </div>
    <div class="carousel-item">
      <img src="https://www.tutorialrepublic.com/examples/images/slide2.png" width="100" height="100" alt="Chicago" >
      <div class="carousel-caption">
        <h3>Los Angeles</h3>
        <p>We had such a great time in LA!</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="https://cdn.educba.com/academy/wp-content/uploads/2019/09/html3png.png.webp" width="1100" height="500" alt="New York" >
      <div class="carousel-caption">
        <h3>Los Angeles</h3>
        <p>We had such a great time in LA!</p>
      </div>   
    </div>
  </div>
  
  <!-- Left and right controls -->
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>

 <div class="header m-auto " id="header">
      <section id="banner">
    <div class="container">
      <div class="row">
      <div class="col-md-6 m-auto ">
          <img src="images/landing.svg" alt="landing photo" class="img-fluid">
        </div>
        <div class="col-md-6 m-auto">
          <p class="promo-title">Welcome to <?php echo $_SESSION['email'] ?> <span style="color: #3F3D56">Simul</span>Educo </p>
          <p class="promo-content">We create a <span style="color: #3F3D56">beautiful website</span> for you & your business. We conduct Hands-on<span style="color: #3F3D56"> workshops </span>on all technologies.</p>
          <div class="shot-cut text-center py-3">
            <a href="<?php echo $base_url ?>/home.php#services" class="btn btn-info font-weight-bold mt-2"> Get Started <span><i class="fa fa-arrow-right"></i></span></a>&nbsp;&nbsp;&nbsp;
            <a href="<?php echo $base_url ?>/college-workshops.php#contact-us" class="btn btn-primary font-weight-bold mt-2">Contact Us <span><i class="fa fa-arrow-right"></i></span></a>&nbsp;&nbsp;&nbsp;
          </div>
        </div> 
      </div>
    </div>
  </section>
    </div>


  <?php require_once 'components/footer.php'; ?>
</body>

</html>


