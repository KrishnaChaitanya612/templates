<?php

include_once "database.php";
session_start();

if(!$_SESSION['email'])
{
    header("Location: http://localhost/templates/login.php");
}



?>