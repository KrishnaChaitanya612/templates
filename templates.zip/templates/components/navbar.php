 <section id="navbar">
     <nav class="navbar my-navbar navbar-expand-lg navbar-light fixed-top  bg-white">
      
        <a class="navbar-brand ml-2" href=" <?php echo $base_url ?>/home.php ">
          <img src="images/logo.png" alt="SimulEduco Logo" />
          </a> 
        <button class="navbar-toggler " type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation" onclick="navFunction(this)">
          <span data-icon="fa-solid:bars" data-inline="false"><div class="bar1"></div>
  <div class="bar2"></div>
  <div class="bar3"></div></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item" >
              <a class="nav-link" href=" <?php echo $base_url ?>/home.php"
                >Home</a
              >
            </li>
            <li class="nav-item">
              <a class="nav-link" href=" <?php echo $base_url ?>/home.php#services">Services</a>
            </li>
           
            <li class="nav-item">
              <div class="dropdown">
            <a  class=" nav-link dropdown-toggle" style="cursor: pointer;" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             Workshops
            </a>
            <div class="dropdown-menu drop-items" aria-labelledby="dropdownMenuButton">
              <a class="dropdown-item drop-item nav-link" href=" <?php echo $base_url ?>/online-workshops.php">Upcoming Workshops</a>
              <a class="dropdown-item drop-item nav-link" href=" <?php echo $base_url ?>/college-workshops.php">Get a Workshop</a>
            </div>
          </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" href=" <?php echo $base_url ?>/home.php#about-us">About Us</a>
            </li>         
            <li class="nav-item">
              <a class="nav-link" href=" <?php echo $base_url ?>/portfolio.php">Portfolio</a>
            </li>
            <li class="nav-item">
               <form action="code.php" method="POST">
                    <button type="submit" style="border:none;cursor: pointer;" name="user_logout" class="nav-link"><i class="fa fa-power-off" aria-hidden="true"></i> &nbsp; Logout</button>
                 </form>
            </li>
          </ul>
        
      </div>
</nav>
  </section>
  <script>
function navFunction(x) {
  x.classList.toggle("change");
}
</script>

<script>
  $('.navbar-nav li').click(function(){
    $('.navbar-nav li').removeClass('nav-active');
    $(this).addClass('nav-active');
});
</script>
<script type="text/javascript">
    $(document).ready(function () {
        var url = window.location;
        $('ul.navbar-nav  a[href="'+ url +'"]').parent().addClass('nav-active');
        $('ul.navbar-nav  a').filter(function() {
             return this.href == url;
        }).parent().addClass('nav-active');
    });
</script> 