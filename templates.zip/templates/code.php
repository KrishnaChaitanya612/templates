<?php

include_once "security.php";



 /* Login   User   */

 if(isset($_POST['user_login']))
{
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM user  WHERE email='$email' AND password ='$password' ";
    $query_run = mysqli_query($connection,$query);
    $row = mysqli_fetch_array($query_run);
    $count=mysqli_num_rows($query_run);
    if($count==1)
    {

        $_SESSION['email'] = $email;
        $_SESSION['user'] = $row['user'];
        
        header('Location: http://localhost/templates/index.php');
    }
    else
    {
        $_SESSION['status'] = "Invalid Email / Password ";
        header('Location: login.php');
    }
}

 /* Register   User   */

 if(isset($_POST['user_register']))
{
    $user = $_POST['user'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query1 = "SELECT * FROM user  WHERE email='$email'";
    $query_run1 = mysqli_query($connection,$query1);
    $count1=mysqli_num_rows($query_run1);
    if($count1>0)
    {
        $_SESSION['status'] = "Email already exsists ";
        header('Location: http://localhost/templates/register.php');
    }
    else
    {
        $query = "INSERT INTO user (user,email,password) VALUES ('$user','$email','$password') ";
        $query_run = mysqli_query($connection,$query);
        $_SESSION['email'] = $email;
        $_SESSION['user'] = $user;
        
        header('Location: http://localhost/templates/index.php');
    }

    
}
 /* Logout  User   */

if(isset($_POST['user_logout']))
{
	session_destroy();
	unset($_SESSION['email']);
	unset($_SESSION['user']);

	header('Location: http://localhost/templates/login.php');
	
}
else{
	echo"Student Not Logout";
}

 /* Program   Add   */

 

 if(isset($_POST['add_user']))
 {
 
        $user = $_POST['user'];
        $email = $_POST['email'];
        $password = $_POST['password'];


       
         $query = "INSERT INTO user (user,email,password) VALUES ('$user','$email','$password')";
         $query_run = mysqli_query($connection,$query);
 
         if($query_run)
         {
             $_SESSION['success'] = "User Added Successfully.'$user'.";
             header('Location: home.php');
         }
         else
         {
             $_SESSION['status'] = "Failed to Add the User";
             header('Location: home.php');
         }
    
 }
 


                              /* Update Program  */

  if(isset($_POST['update_user']))
    {
                                                           
          $id = $_POST['update_userid'];  
          $user = $_POST['user'];
          $email = $_POST['email'];
          $password = $_POST['password'];
 

                                                           
           $query = "UPDATE user SET  user = '$user', email = '$email',password = '$password' WHERE id='$id' ";
           $query_run = mysqli_query($connection,$query);
                                                                   
          if($query_run)
          {
              $_SESSION['success'] = "User  Updated Successfully... :)";
                header('Location: home.php');
         }
         else
          {
             $_SESSION['status'] = "user Not Updated ? Try Again....";
               header('Location: home.php');
            }
                                                           
   }
                           
                           
                                            /* Delete  Program */
                            
    if(isset($_POST['delete_user']))
     {
                                                                                                
            $id = $_POST['delete_userid'];
                                                                                                
             $query = "DELETE FROM user WHERE id='$id' ";
             $query_run = mysqli_query($connection,$query);
                                                                                                        
              if($query_run)
              {
                      $_SESSION['success'] = "User Deleted Successfully... :)";
                       header('Location: home.php');
              }
              else
              {
                     $_SESSION['status'] = "User Not Deleted ? Try Again....";
                      header('Location:  home.php');
              }
                                                                                                
      }   








?>