<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class RegisterModel extends CI_Model{
    public function store($data){
        $first_name=$data['first_name'];
        $last_name=$data['last_name'];
        $email=$data['email'];
        $password=$data['password'];
        $query="insert into users(first_name,last_name,email,password) values('$first_name','$last_name','$email','$password')";
        return $this->db->query($query);

    }
    public function login($email,$password){
        $query = "select * from users where email='$email' and password='$password'";
        $result=$this->db->query($query);
        if ($result->num_rows()==1){
            return $result->row();
        }
        else{
            return false;
        }
    }
}
?>