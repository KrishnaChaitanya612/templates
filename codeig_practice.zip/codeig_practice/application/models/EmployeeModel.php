<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class EmployeeModel extends CI_Model{
    public function store($name,$email){

        $query="insert into employee(name,email) values('$name','$email')";
        return $this->db->query($query);

    }
    public function read(){
        $query = "select * from employee";
        $result=$this->db->query($query);
        if ($result->num_rows()>=1){
            return $result->result();
        }
        else{
            return false;
        }
    }
    public function fetch($id){
        $query="select * from employee where id='$id'";
        $result=$this->db->query($query);
        return $result->result();
    }
    public function update($id,$name,$email){
        $query="update employee set name='$name',email='$email' where id='$id'";
        return $this->db->query($query);
    }
    public function delete($id){
        $query = "delete from employee where id='$id'";
        return $this->db->query($query);
    }
}
?>