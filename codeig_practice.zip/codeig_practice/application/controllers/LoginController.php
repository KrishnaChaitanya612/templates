<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginController extends CI_Controller{
    public function index(){
        if($this->session->userdata('auth')){
            redirect(base_url('home'));
        }
        $this->load->view('templates/header');
        $this->load->view('login');
        $this->load->view('templates/footer');
    }
    public function login(){
        $this->form_validation->set_rules('email','Email','required|trim');
        $this->form_validation->set_rules('password','Password','required|trim');
        if($this->form_validation->run()==FALSE){
            $this->index();
        }
        else{
            $email=$this->input->post('email');
            $password=$this->input->post('password');
            $this->load->model('RegisterModel');
            $row=$this->RegisterModel->login($email,$password);
            if ($row){
                $auth=[
                    "first_name"=>$row->first_name,
                    "last_name"=>$row->last_name,
                    "email"=>$row->email,

                ];
                $this->session->set_userdata('auth',$auth);
                $this->session->set_flashdata('status',"Success login");
                redirect(base_url('home'));
            }
            else{
                $this->session->set_flashdata('status',"email/password is wrong");
                redirect(base_url('login'));

            }
        }

    }
}
?>