<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class UserController extends CI_Controller{

        public function index(){
            if(!$this->session->has_userdata('auth')){
                redirect(base_url('login'));
            }
            $this->load->model('EmployeeModel','emp');
            $result = $this->emp->read();
             $this->load->view('templates/header');

            $this->load->view('home',['result'=>$result]);
            $this->load->view('templates/footer');
        }

        public function logout(){
            $this->session->set_flashdata('status',"logout successfully");
            unset($_SESSION['auth']);
            redirect(base_url('login'));
        }
    }
?>