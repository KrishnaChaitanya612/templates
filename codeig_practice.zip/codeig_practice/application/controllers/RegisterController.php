<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class RegisterController extends CI_Controller{
    public function index(){
         if($this->session->userdata('auth')){
            redirect(base_url('home'));
        }
        $this->load->view('templates/header');
        $this->load->view('register');
        $this->load->view('templates/footer');
    }
    public function register(){
        $this->form_validation->set_rules('first_name','First Name','trim|required|alpha');
        $this->form_validation->set_rules('last_name','Last Name','trim|required|alpha');
        $this->form_validation->set_rules('email','Email','trim|required|is_unique[users.email]|valid_email');
        $this->form_validation->set_rules('password','Password','trim|required');
        $this->form_validation->set_rules('cpassword','Confirm Password','trim|required|matches[password]');
        if($this->form_validation->run()==FALSE){
            $this->index();
        }
        else{
            $data=[
                "first_name"=>$this->input->post('first_name'),
                "last_name"=>$this->input->post("last_name"),
                "email"=>$this->input->post("email"),
                "password"=>$this->input->post("password"),
            ];

            $this->load->model('RegisterModel');
            $checking=$this->RegisterModel->store($data);
            if($checking){
                $this->session->set_flashdata('status',"Successfull");
                redirect(base_url('login'));
            }
            else{
                $this->session->set_flashdata('status',"Failed");
                redirect(base_url('login'));
            }
        }
    }
}
?>