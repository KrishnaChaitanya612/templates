<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class EmployeeController extends CI_Controller{

    public function add(){
        $this->load->view('templates/header');
        $this->load->view('add');
        $this->load->view('templates/footer');
    }
    public function store(){
        $this->form_validation->set_rules('name','Name','required|trim|alpha');
        $this->form_validation->set_rules('email','Email','required|trim|valid_email|is_unique[employee.email]');
        if( $this->form_validation->run()==FALSE){
            $this->add();
        }
        else{
            $name=$this->input->post('name');
            $email=$this->input->post('email');
            $this->load->model('EmployeeModel','emp');
            $this->emp->store($name,$email);
            $this->session->set_flashdata('status','add success');
            redirect(base_url('home'));
        }

    }
    public function edit($id){
        $this->load->model('EmployeeModel','emp');
        $result=$this->emp->fetch($id);
         $this->load->view('templates/header');
        $this->load->view('edit',['result'=>$result]);
        $this->load->view('templates/footer');

    }
    public function update($id){
        $this->form_validation->set_rules('name',"Name","required|trim");
        $this->form_validation->set_rules('email',"Email","required|trim");
        if($this->form_validation->run()==FALSE){
            $this->edit($id);
        }
        else{
            $name=$this->input->post('name');
            $email=$this->input->post('email');
            $this->load->model('EmployeeModel','emp');
            $this->emp->update($id,$name,$email);
            $this->session->set_flashdata('status','update success');
             redirect(base_url('home'));
        }


    }
    public function delete($id){
        $this->load->model('EmployeeModel','emp');
        $this->emp->delete($id);
        $this->session->set_flashdata('status','delete success');
        redirect(base_url('home'));

    }

}
?>