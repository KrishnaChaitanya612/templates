<div class="container">
    <div class="row justify-content-center">
    <div class="col-md-6">
        <?php 
            if($this->session->flashdata('status')){
                ?>
                <div class="alert alert-success">
                <?php echo $this->session->flashdata('status');
                    unset($_SESSION['status']);
                ?>
            </div>
                <?php
            }
            ?>
            <!-- <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                Success
            </div> -->
            <!-- <div class="alert alert-success alert-dismissible">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong>Success!</strong> This alert box could indicate a successful or positive action.
  </div> -->
        <div class="card mt-3">
        <div class="card-header">
            <h4>Login</h4>
        </div>
        <div class="card-body">
            <form action="<?php echo base_url('login') ?>" method="POST">
                <div class="row">
                <div class="col-md-12">
                <div class="form-group">
                    <label for="">Email</label>
                    <input type="email" class="form-control" name="email" value="<?php echo set_value('email') ?>" id="">
                     <small class="text-danger"><?php echo form_error('email') ?></small>
                </div>
                </div>
                <div class="col-md-12">
                <div class="form-group">
                    <label for="">Password</label>
                    <input type="password" class="form-control" name="password" value="<?php echo set_value('password') ?>" id="">
                     <small class="text-danger"><?php echo form_error('password') ?></small>
                </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <button type="submit" class="btn btn-outline-success">Login</button>
                    </div>
                </div>
                </div>
            </form>
        </div>
    </div>
    </div>
    </div>
</div>