<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 ">    
                <div class="card p-2">
                    <div class="header">
                        <div class="row">
                        <div class="col-md-12 d-flex justify-content-between">
                        <p><?php echo $this->session->userdata('auth')['email']; ?></p>
                        <a href="<?php echo base_url('logout') ?>" class="btn btn-danger">logout</a>
                        </div>
                        </div>
                </div>
            </div>
       
    </div>
</div>

<div class="container mt-3">
    <div class="row justify-content-center">
        <div class="col-md-8 ">    
            <?php 
            if($this->session->flashdata('status')){
                ?>
                <div class="alert alert-success">
                <?php echo $this->session->flashdata('status');
                    unset($_SESSION['status']);
                ?>
            </div>
                <?php
            }
            ?>
                <div class="card p-2">
                    <div class="card-header">
                        <div class="row">
                        <div class="col-md-12 d-flex justify-content-between">
                        <h3>Show employees</h3>
                        <a href="<?php echo base_url('add') ?>" class="btn btn-outline-info">Add Employee</a>
                        </div>
                        </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Sno</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            if($result){
                            foreach($result as $row) {
                                ?>
                            <tr>
                                <td><?php echo $row->id; ?></td>
                                <td><?php echo $row->name; ?></td>
                                <td><?php echo $row->email; ?>@123</td>
                                <td><a href="<?php echo base_url('edit/'.$row->id) ?>" class="btn btn-outline-info">Edit</a></td>
                                <td><a href="<?php echo base_url('delete/'.$row->id) ?>" class="btn btn-outline-danger">Delete</a></td>
                            </tr>
                                <?php
                            }
                        }else{
                            ?>
                            <tr>
                                <p style="width:100%">No data</p>
                        </tr>
                            <?php
                        }
                            ?>
                            
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
       
    </div>
</div>