<div class="container">
    <div class="row justify-content-center">
    <div class="col-md-6">
        <?php 
            if($this->session->flashdata('status')){
                ?>
                <div class="alert alert-success">
                <?php echo $this->session->flashdata('status');
                    unset($_SESSION['status']);
                ?>
            </div>
                <?php
            }
            ?>
        <div class="card mt-3">
        <div class="card-header">
            <h4>Add Employee</h4>
        </div>
        <div class="card-body">
            <form action="<?php echo base_url('store') ?>" method="POST">
                <div class="row">

                 <div class="col-md-12">
                <div class="form-group">
                    <label for="">Name</label>
                    <input type="text" class="form-control" name="name" value="<?php echo set_value('name') ?>" id="">
                     <small class="text-danger"><?php echo form_error('name') ?></small>
                </div>
                </div>

                <div class="col-md-12">
                <div class="form-group">
                    <label for="">Email</label>
                    <input type="email" class="form-control" name="email" value="<?php echo set_value('email') ?>" id="">
                     <small class="text-danger"><?php echo form_error('email') ?></small>
                </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                        <button type="submit" class="btn btn-outline-success">Save</button>
                    </div>
                </div>
                </div>
            </form>
        </div>
    </div>
    </div>
    </div>
</div>