<div class="container">
    <div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card mt-3">
        <div class="card-header">
            <h4>Register</h4>
        </div>
        <div class="card-body">
            <form action="<?php echo base_url('register') ?>" method="POST">
                <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                    <label for="">First Name</label>
                    <input type="text" class="form-control" name="first_name" value="<?php echo set_value('first_name') ?>" id="">
                    <small class="text-danger"><?php echo form_error('first_name') ?></small>
                </div>
               </div>

                <div class="col-md-6">
                     <div class="form-group">
                    <label for="">Last Name</label>
                    <input type="text" class="form-control" name="last_name" value="<?php echo set_value('last_name') ?>" id="">
                    <small class="text-danger"><?php echo form_error('last_name') ?></small>

                </div>
                </div>
                <div class="col-md-12">
                <div class="form-group">
                    <label for="">Email</label>
                    <input type="email" class="form-control" name="email" value="<?php echo set_value('email') ?>" id="">
                     <small class="text-danger"><?php echo form_error('email') ?></small>
                </div>
                </div>
                <div class="col-md-12">
                <div class="form-group">
                    <label for="">Password</label>
                    <input type="password" class="form-control" name="password" value="<?php echo set_value('password') ?>" id="">
                     <small class="text-danger"><?php echo form_error('password') ?></small>
                </div>
                </div>
                <div class="col-md-12">
                <div class="form-group">
                    <label for="">Confirm Password</label>
                    <input type="password" class="form-control" name="cpassword" value="<?php echo set_value('cpassword') ?>" id="">
                     <small class="text-danger"><?php echo form_error('cpassword') ?></small>
                </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <button type="submit" class="btn btn-outline-success">Register</button>
                    </div>
                </div>
                </div>
            </form>
        </div>
    </div>
    </div>
    </div>
</div>